# -*- coding: utf-8 -*- 

import os
import sys
import xbmc
import urllib,urllib2
import xbmcvfs
import xbmcaddon
import xbmcgui,xbmcplugin,shutil
from zipfile import ZipFile
from cStringIO import StringIO
import uuid
import unicodedata
import re
from modules import client

__addon__ = xbmcaddon.Addon()
__author__     = __addon__.getAddonInfo('author')
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__version__    = __addon__.getAddonInfo('version')
__language__   = __addon__.getLocalizedString

__cwd__        = xbmc.translatePath( __addon__.getAddonInfo('path') ).decode("utf-8")
__profile__    = xbmc.translatePath( __addon__.getAddonInfo('profile') ).decode("utf-8")
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) ).decode("utf-8")
__temp__       = xbmc.translatePath( os.path.join( __profile__, 'temp', '') ).decode("utf-8")

sys.path.append (__resource__)
useragent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.90 Safari/537.36'
def Search( item ):
  subtitles_list = []
  if item['tvshow'] == '':
    title = item['title']
  else:
    title = item['tvshow'] + ' - ' + item['season'] + 'x' + item['episode']

  if re.match('(.+?) - ([0-9]+)x([0-9]+)',title) is not None:
    p = re.findall('(.+?) - ([0-9]+)x([0-9]+)',title)[0]
    result = client.request("http://titlovi.net/titlovi/?prijevod="+p[0].replace(" ","+")+"&jezik=bosanski|hrvatski|srpski&t=2&s="+p[1]+"&e="+p[2]+"&sort=4",
                             referer="http://titlovi.net/",
                             headers={'User-Agent': useragent}
                             )
  else:
    result = client.request("http://titlovi.net/titlovi/?prijevod="+item["title"].replace(" ","+")+"&jezik=bosanski|hrvatski|srpski&t=1&g="+item["year"]+"&sort=4",
                         referer="http://titlovi.net/",
                         headers={'User-Agent': useragent}
                         )
  result = result.replace('\n','')
  s ='<ul class="titlovi">(.+?)<div class="paging">'
  ul = re.findall(s,result)[0]
  try:
    lista = re.findall('class="s0xe0y">(.+?)<.+?h4>(.+?)<.+?lang.+?src="http:\/\/titlovi\.com\/content\/images\/flags\/(.+?)".+?href=".+?-(\d.+?)\/"',ul)
  except:
    pass
  lista = re.findall('\/">.+?<.+?<i>(.+?)<\/i>.+?h4>(.+?)<span.+?lang.+? src="http:\/\/titlovi\.com\/content\/images\/flags\/(.+?)".+?href=".+?(\d.+?)\/"',ul)
  for it in lista:
    flag = it[2][:2]
    if(flag == 'rs'):flag = "sr"
    subtitles_list.append({'filename'      : title + "  - " + it[0] + " - " +it[1],
                           'link'          : urllib.quote('http://titlovi.net/download/?type=1&mediaid='+it[3]),
                           'language_name' : flag,
                           'language_flag' : flag
                            })
  if subtitles_list:
    for it in subtitles_list:
      listitem = xbmcgui.ListItem(label=it["language_name"],
                                  label2=it["filename"],
                                  thumbnailImage=it["language_flag"]
                                  )
      url = "plugin://%s/?action=download&link=%s&filename=%s" %(__scriptid__,it["link"],it["filename"])
      xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=False)

def old_extractor(temp_archive, subtitle_list = []):
    exts = [".srt", ".sub", ".txt", ".smi", ".ssa", ".ass"]
    zip_exts = [".zip", ".rar"]
    for subfile in xbmcvfs.listdir(temp_archive)[1]:
            file = os.path.join(__temp__, subfile.decode('utf-8'))
            log(__name__, 'archive names: %s' % file)
            if (os.path.splitext(file)[1] in exts):
                subtitle_list.append(file)
            elif (os.path.splitext(file)[1] in zip_exts):
                log(__name__, 'Found archive file %s' % file)
                xbmc.executebuiltin(('XBMC.Extract("%s","%s")' % (file, __temp__,))
                    .encode('utf-8'), True)
                old_extractor(file, subtitle_list)
    return subtitle_list

def Download(url, filename, language_name=None):
    if xbmcvfs.exists(__temp__):
        shutil.rmtree(__temp__)
    xbmcvfs.mkdirs(__temp__)
    subtitle_list = []

    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', useragent)
        response = urllib2.urlopen(req)
        raw = response.read()
        archive = ZipFile(StringIO(raw), 'r')
        files = archive.namelist()
        files.sort()
        index = 1
        for file in files:
            contents = archive.read(file)
            extension = file[file.rfind('.') + 1:]

            if len(files) == 1: dest = os.path.join(__temp__, "%s.%s" % (str(uuid.uuid4()), extension))
            else: dest = os.path.join(__temp__, "%s.%d.%s" % (str(uuid.uuid4()), index, extension))
            f = open(dest, 'wb')
            f.write(contents)
            f.close()
            subtitle_list.append(dest)

            index += 1
    except:
        req = urllib2.Request(url)
        req.add_header('User-Agent', useragent)
        response = urllib2.urlopen(req)
        content = response.read()
        response.close()
        temp_file = os.path.join(__temp__,filename+".zip")
        with open(temp_file, "wb") as subFile:
            subFile.write(content)
        subFile.close()
        xbmc.sleep(500)
        xbmc.executebuiltin(('XBMC.Extract("%s","%s")' % (temp_file,__temp__,)).encode('utf-8'), True)
        for file in os.listdir(__temp__):
          if file.endswith(".srt"):
            subtitles_list = file

    return subtitle_list


def normalizeString(str):
  return unicodedata.normalize(
         'NFKD', unicode(unicode(str, 'utf-8'))
         ).encode('ascii','ignore')

def get_params(string=""):
    param = []
    if string == "":
        paramstring = sys.argv[2]
    else:
        paramstring = string
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param

params = get_params()

if params['action'] == 'search' or params['action'] == 'manualsearch':
    item = {}
    item['temp'] = False
    item['rar'] = False
    item['mansearch'] = False
    item['year'] = xbmc.getInfoLabel("VideoPlayer.Year")  # Year
    item['season'] = str(xbmc.getInfoLabel("VideoPlayer.Season"))  # Season
    item['episode'] = str(xbmc.getInfoLabel("VideoPlayer.Episode"))  # Episode

    if 'searchstring' in params:
        item['mansearch'] = True
        item['mansearchstr'] = params['searchstring']

    item['tvshow'] = normalizeString(
        xbmc.getInfoLabel("VideoPlayer.TVshowtitle"))
    item['title'] = normalizeString(
        xbmc.getInfoLabel("VideoPlayer.OriginalTitle"))
    item['file_original_path'] = urllib.unquote(
        xbmc.Player().getPlayingFile().decode('utf-8'))

    if item['title'] == "":
        item['title'] = normalizeString(
            xbmc.getInfoLabel("VideoPlayer.Title"))

    item['title'] = item['title'].replace('[B]', '')
    item['title'] = item['title'].replace('[/B]', '')
    item['title'] = item['title'].replace('  ', ' ')

    find_year = re.findall('\((\d{4})\)', item['title'])
    if find_year:
        item['title'] = item['title'].replace(' (' + find_year[0] + ')', '')
        if not item['year']:
            item['year'] = find_year[0]
    else:
        if not item['year']:
            item['year'] = ''

    if item['episode'].lower().find("s") > -1:
        item['season'] = "0"
        item['episode'] = item['episode'][-1:]

    if (item['file_original_path'].find("http") > -1):
        item['temp'] = True

    elif (item['file_original_path'].find("rar://") > -1):
        item['rar'] = True
        item['file_original_path'] = os.path.dirname(item['file_original_path'][6:])

    elif (item['file_original_path'].find("stack://") > -1):
        stackPath = item['file_original_path'].split(" , ")
        item['file_original_path'] = stackPath[0][8:]

    item['3let_language'] = ['hr']
    Search(item)

elif params['action'] == 'download':
    url = params['link']
    subs = Download(urllib.unquote_plus(url), params["filename"])
    for sub in subs:
      listitem = xbmcgui.ListItem(label=sub)
      xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),
                                  url=sub,
                                  listitem=listitem,
                                  isFolder=False)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
  
  
  
  
  
  
  
  
  
    
