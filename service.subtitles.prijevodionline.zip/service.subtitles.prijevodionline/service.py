# -*- coding: utf-8 -*- 

import os
import sys
import xbmc
import urllib,urllib2
import xbmcvfs
import xbmcaddon
import xbmcgui,xbmcplugin,shutil
from zipfile import ZipFile
from cStringIO import StringIO
import uuid
import unicodedata

import re
from modules import client

__addon__ = xbmcaddon.Addon()
__author__     = __addon__.getAddonInfo('author')
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__version__    = __addon__.getAddonInfo('version')
__language__   = __addon__.getLocalizedString

__cwd__        = xbmc.translatePath( __addon__.getAddonInfo('path') ).decode("utf-8")
__profile__    = xbmc.translatePath( __addon__.getAddonInfo('profile') ).decode("utf-8")
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) ).decode("utf-8")
__temp__       = xbmc.translatePath( os.path.join( __profile__, 'temp', '') ).decode("utf-8")

sys.path.append (__resource__)
useragent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.90 Safari/537.36'
def Search( item ):
  subtitles_list = []
  
  if item['tvshow'] == '': title = item['title']
  else: title = item['tvshow'] + ' - ' + item['season'] + 'x' + item['episode']
  if re.match('(.+?) - ([0-9]+)x([0-9]+)',title) is not None:
    #regex za odvajanje naslova od ep i sezona
    p = re.findall('(.+?) - ([0-9]+)x([0-9]+)',title)[0]
    #request za listu pod nekim karakterom eg. e,a,c
    result = client.request('http://www.prijevodi-online.org/serije/index/'+title[0].lower(),
                             referer="http://www.prijevodi-online.org/",
                             headers={'User-Agent': useragent}
                             )
    #regex string za izdvajanje serije iz liste pod odredjenim karakterom
    s ='<td class="naziv"><a href="(.+?)" title="('+p[0]+'.*)">'
    #regex za pronalazenje serije iz liste pod odredjenim karakterom
    sep = re.findall(s,result)
    for serija in sep: 
      #request za stranicu serije koja je pronadjena
      result2 = client.request('https://www.prijevodi-online.org'+serija[0],
                                referer="https://www.prijevodi-online.org/",
                                headers={'User-Agent': useragent}
                                )

      #regex za izdvajanje djela html sa epizodama
      epizodedio = re.findall('<div id=\"epizode\">([^+]*)<script type=\"text\/javascript\">epizode\.key = \'([^\']*)',
                               result2.replace('\r','').replace('\n','').replace('\t','')
                               )[0]
      #regex za izdvajanje epizoda serije koji su pronadjeni
      lista = re.findall('Sezona '+p[1]+'<\/h3>.+?<li class=\"broj\">'+p[2]+'\..+?<li class=\"naziv\">[^>]+rel=\"([^"]*)\"[^>]+>(.+?)<',
                          epizodedio[0]
                          )[0]

      #request za header sa fajlom od epizode
      prevodi = client.request('https://www.prijevodi-online.org'+lista[0],
                                referer='https://www.prijevodi-online.org'+lista[0],
                                headers={'X-Requested-With': 'XMLHttpRequest',
                                'User-Agent': useragent,
                                'Content-Type': 'application/x-www-form-urlencoded;'},
                                post = urllib.urlencode({'key': epizodedio[1]})
                                )

      #print prevodi.replace('\r','').replace('\n','')
      #regex za izdvajanje linka i imena fajla
      lista = re.findall('href=\"([^\"]*)\"[^>]*>(.+?)<.+?=\"user\".+?>(.+?)<',
                          prevodi.replace('\r','').replace('\n','')
                          )

      #dodavalje linkova i imena u subtitle kontejner za prikaz u gui
      for item in lista:
        subtitles_list.append({'filename'      : item[1],
                               'link'          : 'http://www.prijevodi-online.org'+item[0],
                               'language_name' : item[0][-2:],
                               'language_flag' : item[0][-2:]
                                })

  if subtitles_list:
    for it in subtitles_list:
      listitem = xbmcgui.ListItem(label=it["language_name"],
                                  label2=it["filename"],
                                  thumbnailImage=it["language_flag"]
                                  )
      url = "plugin://%s/?action=download&link=%s&filename=%s" %(__scriptid__,it["link"],it["filename"])
      xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=False)


def Download(url, filename, language_name=None):
    if xbmcvfs.exists(__temp__):
        shutil.rmtree(__temp__)
    xbmcvfs.mkdirs(__temp__)
    subtitle_list = []
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', useragent)
        response = urllib2.urlopen(req)
        raw = response.read()
        response.close()
        archive = ZipFile(StringIO(raw), 'r')
        files = archive.namelist()
        files.sort()
        index = 1
        for file in files:
            contents = archive.read(file)
            extension = file[file.rfind('.') + 1:]

            if len(files) == 1: dest = os.path.join(__temp__, "%s.%s" % (str(uuid.uuid4()), extension))
            else: dest = os.path.join(__temp__, "%s.%d.%s" % (str(uuid.uuid4()), index, extension))
            f = open(dest, 'wb')
            f.write(contents)
            f.close()
            subtitle_list.append(dest)
            index += 1
    except:
        req = urllib2.Request(url)
        req.add_header('User-Agent', useragent)
        response = urllib2.urlopen(req)
        temp_filename = response.info()['Content-Disposition']
        pos = temp_filename.find('filename=')
        temp_filename = temp_filename[pos+10:-1]
        content = response.read()
        response.close()
        temp_file = os.path.join(__temp__, temp_filename)
        with open(temp_file, "wb") as subFile:
            subFile.write(content)
        subFile.close()
        xbmc.sleep(500)
        xbmc.executebuiltin(('XBMC.Extract("%s","%s")' % (temp_file,__temp__,)).encode('utf-8'), True)
        for file in os.listdir(__temp__):
          if file.endswith(".srt"):
            dest = os.path.join(__temp__,file)
            subtitle_list.append(dest)

    return subtitle_list


def normalizeString(str):
  return unicodedata.normalize(
         'NFKD', unicode(unicode(str, 'utf-8'))
         ).encode('ascii','ignore')

def get_params(string=""):
    param = []
    if string == "":
        paramstring = sys.argv[2]
    else:
        paramstring = string
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param

params = get_params()

if params['action'] == 'search' or params['action'] == 'manualsearch':
    item = {}
    item['temp'] = False
    item['rar'] = False
    item['mansearch'] = False
    item['year'] = xbmc.getInfoLabel("VideoPlayer.Year")  # Year
    item['season'] = str(xbmc.getInfoLabel("VideoPlayer.Season"))  # Season
    item['episode'] = str(xbmc.getInfoLabel("VideoPlayer.Episode"))  # Episode

    if 'searchstring' in params:
        item['mansearch'] = True
        item['mansearchstr'] = params['searchstring']

    # Show
    item['tvshow'] = normalizeString(
        xbmc.getInfoLabel("VideoPlayer.TVshowtitle"))
    # try to get original title
    item['title'] = normalizeString(
        xbmc.getInfoLabel("VideoPlayer.OriginalTitle"))

    # Full path of a playing file
    item['file_original_path'] = urllib.unquote(
        xbmc.Player().getPlayingFile().decode('utf-8'))

    if item['title'] == "":
         # no original title, get just Title
        item['title'] = normalizeString(
            xbmc.getInfoLabel("VideoPlayer.Title"))

    # if (item['title'].find('[B]')):
    item['title'] = item['title'].replace('[B]', '')
    item['title'] = item['title'].replace('[/B]', '')
    item['title'] = item['title'].replace('  ', ' ')

    find_year = re.findall('\((\d{4})\)', item['title'])
    if find_year:
        # if found year remove year from title
        item['title'] = item['title'].replace(' (' + find_year[0] + ')', '')
        if not item['year']:
            item['year'] = find_year[0]
    else:
        if not item['year']:
            item['year'] = ''

    # Check if season is "Special"
    if item['episode'].lower().find("s") > -1:
        item['season'] = "0"
        item['episode'] = item['episode'][-1:]

    if (item['file_original_path'].find("http") > -1):
        item['temp'] = True

    elif (item['file_original_path'].find("rar://") > -1):
        item['rar'] = True
        item['file_original_path'] = os.path.dirname(item['file_original_path'][6:])

    elif (item['file_original_path'].find("stack://") > -1):
        stackPath = item['file_original_path'].split(" , ")
        item['file_original_path'] = stackPath[0][8:]

    #['scc','eng']
    item['3let_language'] = ['hr']

    Search(item)

if params['action'] == 'download':
    url = params['link']
    subs = Download(url, params["filename"])
    for sub in subs:
      listitem = xbmcgui.ListItem(label=sub)
      xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),
                                  url=sub,
                                  listitem=listitem,
                                  isFolder=False)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
  
  
  
  
  
  
  
  
  
    
