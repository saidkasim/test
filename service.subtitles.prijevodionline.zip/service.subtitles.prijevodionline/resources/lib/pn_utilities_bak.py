# -*- coding: utf-8 -*- 

import sys
import os
import xmlrpclib
import unicodedata
import struct
import urllib, zlib
import xbmc, xbmcvfs
  
__addon__      = sys.modules[ "__main__" ].__addon__
__scriptname__ = sys.modules[ "__main__" ].__scriptname__
__version__    = sys.modules[ "__main__" ].__version__
__cwd__        = sys.modules[ "__main__" ].__cwd__
__language__   = sys.modules[ "__main__" ].__language__
__scriptid__   = sys.modules[ "__main__" ].__scriptid__


def log(module, msg):
  xbmc.log((u"### [%s] - %s" % (module,msg,)).encode('utf-8'),level=xbmc.LOGDEBUG ) 

def normalizeString(str):
  return unicodedata.normalize(
         'NFKD', unicode(unicode(str, 'utf-8'))
         ).encode('ascii','ignore')

def OpensubtitlesHash(item):
    try:
      try:
        return OpensubtitlesHashRar(item['file_original_path'])
      except:
        pass
        
      log( __scriptid__,"Hash Standard file")  
      longlongformat = 'q'  # long long
      bytesize = struct.calcsize(longlongformat)
      
      f = xbmcvfs.File(item['file_original_path'])
      filesize = f.size()
      hash = filesize
      
      if filesize < 65536 * 2:
          return "SizeError"
      
      buffer = f.read(65536)
      f.seek(max(0,filesize-65536),0)
      buffer += f.read(65536)
      f.close()
      for x in range((65536/bytesize)*2):
          size = x*bytesize
          (l_value,)= struct.unpack(longlongformat, buffer[size:size+bytesize])
          hash += l_value
          hash = hash & 0xFFFFFFFFFFFFFFFF
      
      returnHash = "%016x" % hash
    except:
      returnHash = "000000000000"

    return returnHash

def OpensubtitlesHashRar(firstrarfile):
    log( __scriptid__,"Hash Rar file")
    f = xbmcvfs.File(firstrarfile)
    a=f.read(4)
    if a!='Rar!':
        raise Exception('ERROR: This is not rar file.')
    seek=0
    for i in range(4):
        f.seek(max(0,seek),0)
        a=f.read(100)        
        type,flag,size=struct.unpack( '<BHH', a[2:2+5]) 
        if 0x74==type:
            if 0x30!=struct.unpack( '<B', a[25:25+1])[0]:
                raise Exception('Bad compression method! Work only for "store".')            
            s_partiizebodystart=seek+size
            s_partiizebody,s_unpacksize=struct.unpack( '<II', a[7:7+2*4])
            if (flag & 0x0100):
                s_unpacksize=(struct.unpack( '<I', a[36:36+4])[0] <<32 )+s_unpacksize
                log( __name__ , 'Hash untested for files biger that 2gb. May work or may generate bad hash.')
            lastrarfile=getlastsplit(firstrarfile,(s_unpacksize-1)/s_partiizebody)
            hash=addfilehash(firstrarfile,s_unpacksize,s_partiizebodystart)
            hash=addfilehash(lastrarfile,hash,(s_unpacksize%s_partiizebody)+s_partiizebodystart-65536)
            f.close()
            return (s_unpacksize,"%016x" % hash )
        seek+=size
    raise Exception('ERROR: Not Body part in rar file.')

def dec2hex(n, l=0):
  # return the hexadecimal string representation of integer n
  s = "%X" % n
  if (l > 0) :
    while len(s) < l:
      s = "0" + s 
  return s

def invert(basestring):
  asal = [basestring[i:i+2]
          for i in range(0, len(basestring), 2)]
  asal.reverse()
  return ''.join(asal)

def calculateSublightHash(filename):

  DATA_SIZE = 128 * 1024;

  if not xbmcvfs.exists(filename) :
    return "000000000000"
  
  fileToHash = xbmcvfs.File(filename)

  if fileToHash.size(filename) < DATA_SIZE :
    return "000000000000"

  sum = 0
  hash = ""
  
  number = 2
  sum = sum + number
  hash = hash + dec2hex(number, 2) 
  
  filesize = fileToHash.size(filename)
  
  sum = sum + (filesize & 0xff) + ((filesize & 0xff00) >> 8) + ((filesize & 0xff0000) >> 16) + ((filesize & 0xff000000) >> 24)
  hash = hash + dec2hex(filesize, 12) 
  
  buffer = fileToHash.read( DATA_SIZE )
  begining = zlib.adler32(buffer) & 0xffffffff
  sum = sum + (begining & 0xff) + ((begining & 0xff00) >> 8) + ((begining & 0xff0000) >> 16) + ((begining & 0xff000000) >> 24)
  hash = hash + invert(dec2hex(begining, 8))

  fileToHash.seek(filesize/2,0)
  buffer = fileToHash.read( DATA_SIZE )
  middle = zlib.adler32(buffer) & 0xffffffff
  sum = sum + (middle & 0xff) + ((middle & 0xff00) >> 8) + ((middle & 0xff0000) >> 16) + ((middle & 0xff000000) >> 24)
  hash = hash + invert(dec2hex(middle, 8))

  fileToHash.seek(filesize-DATA_SIZE,0)
  buffer = fileToHash.read( DATA_SIZE )
  end = zlib.adler32(buffer) & 0xffffffff
  sum = sum + (end & 0xff) + ((end & 0xff00) >> 8) + ((end & 0xff0000) >> 16) + ((end & 0xff000000) >> 24)
  hash = hash + invert(dec2hex(end, 8))
  
  fileToHash.close()
  hash = hash + dec2hex(sum % 256, 2)
  
  return hash.lower()

class PNServer:
  def Create(self):
    self.subtitles_list = []
    self.connected = False

  def SearchSubtitlesWeb( self, item):
    if len(item['tvshow']) > 1:
      item['title'] = item['tvshow']
    
    if (__addon__.getSetting("PNmatch") == 'true'):
      url =  SEARCH_URL_HASH % (item['title'].replace(" ","+"),
                               ','.join(item['3let_language']),
                               str(item['year']),
                               str(item['season']), 
                               str(item['episode']),
                               '%s,sublight:%s,sublight:%s' % (item['OShash'],item['SLhash'],md5(item['SLhash']).hexdigest() )
                               )
    else:
      url =  'prijevodi-online.org'

    log( __scriptid__ ,"Search URL - %s" % (url))
    
    subtitles = self.fetch(url)

    if subtitles:
      for subtitle in subtitles:
        filename    = self.get_element(subtitle, "release")

        if filename == "":
          filename = self.get_element(subtitle, "title")
        
        hashMatch = False
        if (item['OShash'] in self.get_element(subtitle, "exactHashes") or 
           item['SLhash'] in self.get_element(subtitle, "exactHashes")):
          hashMatch = True

        self.subtitles_list.append({'filename'      : filename,
                                    'link'          : self.get_element(subtitle, "pid"),
                                    'movie_id'      : self.get_element(subtitle, "movieId"),
                                    'season'        : self.get_element(subtitle, "tvSeason"),
                                    'episode'       : self.get_element(subtitle, "tvEpisode"),
                                    'language_name' : self.get_element(subtitle, "languageName"),
                                    'language_flag' : self.get_element(subtitle, "language"),
                                    'rating'        : str(int(float(self.get_element(subtitle, "rating")))*2),
                                    'sync'          : hashMatch,
                                    'hearing_imp'   : "n" in self.get_element(subtitle, "flags")
                                    })
      self.mergesubtitles()
    return self.subtitles_list
  
  def Download(self,params):
    print params
    subtitle_ids = []
    if (__addon__.getSetting("PNmatch") == 'true' and params["hash"] != "000000000000"):
      self.Login()
      if params["match"] == "True":
        subtitle_ids.append(str(params["link"]))

      log( __scriptid__ ,"Sending match to Podnapisi server")
      result = self.podserver.match(self.pod_session, params["hash"], params["movie_id"], int(params["season"]), int(params["episode"]), subtitle_ids)
      if result['status'] == 200:
        log( __scriptid__ ,"Match successfuly sent")

    return str(params["link"])

  def get_element(self, element, tag):
    if element.getElementsByTagName(tag)[0].firstChild:
      return element.getElementsByTagName(tag)[0].firstChild.data
    else:
      return ""  

  def fetch(self,url):
    socket = urllib.urlopen( url )
    result = socket.read()
    socket.close()
    xmldoc = minidom.parseString(result)
    return xmldoc.getElementsByTagName("subtitle")    

  def compare_columns(self, b, a):
    return cmp( b["language_name"], a["language_name"] )  or cmp( a["sync"], b["sync"] ) 

  def mergesubtitles(self):
    if( len ( self.subtitles_list ) > 0 ):
      self.subtitles_list = sorted(self.subtitles_list, self.compare_columns)
       
